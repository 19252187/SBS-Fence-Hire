<?php
/**
 * RevSlider template.
 *
 * @author     ThemeFusion
 * @copyright  (c) Copyright by ThemeFusion
 * @link       http://theme-fusion.com
 * @package    Avada
 * @subpackage Core
 * @since      5.1
 */

if ( function_exists( 'putRevSlider' ) ) {
	putRevSlider( $name );
}

/* Omit closing PHP tag to avoid "Headers already sent" issues. */
